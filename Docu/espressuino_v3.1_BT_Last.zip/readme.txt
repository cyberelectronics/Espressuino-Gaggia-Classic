Tested only with Arduino 1.0.5


If you find the Espressuino or my other projects useful, please consider donating what you think the projects is worth via Paypal.

Donations are used solely for purchasing hardware to improve and extend Espressuino and other homemade electronics projects. 


Thank you!